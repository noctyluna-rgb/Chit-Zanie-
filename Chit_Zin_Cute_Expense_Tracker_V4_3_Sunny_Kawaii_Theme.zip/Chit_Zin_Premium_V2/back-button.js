import { App } from '@capacitor/app';

App.addListener('backButton', () => {
  if (typeof window.handleAppBack === 'function') window.handleAppBack();
});

window.ChitZinNativeExit = () => App.exitApp();

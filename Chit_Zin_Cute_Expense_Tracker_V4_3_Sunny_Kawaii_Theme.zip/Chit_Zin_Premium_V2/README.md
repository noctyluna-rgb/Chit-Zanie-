# ချစ်ဇနီးလေး — Cute Money Book v1.2.0

A Burmese household money ledger and budgeting app built with Vite + Capacitor.

## Included
- Income and expense entries with dates and descriptions
- Monthly balance and transaction summary dashboard
- Recent transactions, reports, spending breakdown and savings goals
- Grocery, household, notes and family planning tools retained from the original project
- Four selectable pastel themes: Cotton Candy, Dreamy Lilac, Peach Cream and Mint Garden
- In-app logo image picker (saves the chosen logo in this app's local storage)
- Pink mascot launcher icon and coordinated finance character stickers
- JSON backup/restore and CSV export
- No music player or audio playback feature

## Build APK
The GitHub Actions workflow builds a debug APK and uploads it as `Chit-Zin-Money-Book-v1.2.0-APK`.

## Logo notes
The logo picker changes the logo shown inside the app on that device. To change the Android Home Screen launcher icon, replace `public/launcher-icon.png` with a square PNG and rebuild the APK. Android does not allow an installed app to replace its own launcher icon directly from a normal in-app image picker.

## Data
Entries are stored locally in the browser/WebView storage on the device. Export a JSON backup regularly before reinstalling or clearing app data.


## V3.1 Back-button behavior
- Back from an inner screen returns to Home.
- First Back on Home opens an exit confirmation using the existing deployed-by photo.
- Second Back while the popup is open exits the Android app through the Capacitor App plugin.

# ချစ်ဇနီး - အသုံးစရိတ် (Android Project)

## GitHub မှာ ဖုန်းနဲ့တင်ရန်

1. GitHub မှာ repository အသစ်ဖွင့်ပါ။
2. ဒီ ZIP ဖိုင်ကို repository ရဲ့ ပထမစာမျက်နှာ (root) မှာ upload လုပ်ပါ။ ZIP ကို မဖြည်ဘဲ တင်လို့ရပါတယ်။
3. Repository မှာ `.github/workflows/build-android.yml` ဆိုတဲ့ path နဲ့ workflow ဖိုင်အသစ်တစ်ခု ဖန်တီးပြီး ဒီ project ထဲက workflow စာသားကို ထည့်ပါ။ သီးခြားပေးထားတဲ့ `build-android.yml` ဖိုင်ကိုလည်း ဖွင့်ပြီး စာသားကူးယူနိုင်ပါတယ်။
4. Commit လုပ်ပြီး `Actions` tab ကိုဖွင့်ပါ။ `Chit Zin - Android Build` ကိုရွေးပြီး `Run workflow` နှိပ်ပါ။
5. အောင်မြင်ရင် `chit-zin-android-build` artifact ထဲမှာ APK နဲ့ AAB ရပါမယ်။

## Build ထွက်လာမည့်ဖိုင်များ

- `chit-zin-debug.apk` — ဖုန်းမှာ စမ်းသပ်တင်ရန်။
- `app-release-unsigned.aab` — Release AAB; signing key မထည့်ရသေးလျှင် unsigned ဖြစ်မည်။
- Signing key ထည့်ထားလျှင် release AAB ကို signed ထုတ်ပေးမည်။

## Play Store signing (နောက်မှလုပ်ရန်)

GitHub repository > Settings > Secrets and variables > Actions ထဲမှာ အောက်ပါ Secrets လေးခုကို ထည့်ပါ။

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Keystore ကို လုံခြုံစွာ ဖန်တီးပြီး Base64 ပြောင်းပြီးမှ ထည့်ပါ။ Keystore သို့မဟုတ် password ကို repository ထဲ မတင်ပါနှင့်။ Signing key မရှိသေးရင် အခုအဆင့်ကို မလုပ်သေးပါနှင့်။

## Project မှတ်ချက်များ

- Package name: `com.momo.expensetracker` (Play Store တင်ပြီးနောက် package name မပြောင်းနိုင်သလို အခြား App နဲ့လည်း မတူရပါ)။
- Android compile/target SDK: 36 (Android 16)။
- Transaction data သည် WebView localStorage ထဲတွင် ဖုန်းပေါ်မှာ သိမ်းသည်။ App ကို uninstall လုပ်ခြင်း သို့မဟုတ် app data ရှင်းခြင်းကြောင့် data ပျောက်နိုင်သဖြင့် CSV backup ထုတ်ထားပါ။
- လက်ရှိ HTML ထဲက Tailwind, Lucide, Chart.js နှင့် Padauk fonts ကို CDN ကနေ ခေါ်ထားသေးသည်။ ထို့ကြောင့် data သိမ်းတာက local ဖြစ်ပေမဲ့ UI အစိတ်အပိုင်းအချို့က ပထမတင်ချိန်/အသုံးပြုချိန် Internet လိုနေသေးသည်။ Fully offline ဖြစ်ဖို့ အဲဒီ assets တွေကို app ထဲ local ထည့်သွင်းရမည်။
- AdMob SDK ကို ဒီ build ထဲ မထည့်ရသေးပါ။ ကြော်ငြာကို Play Store မတင်မီ သီးခြားထည့်သွင်းပြီး Test Ads နဲ့ စမ်းသပ်ရမည်။
